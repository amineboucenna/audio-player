import 'package:flutter/material.dart';

class AppColors {
  static const Color background = Color(0xFF323232);
  static const Color gold = Color(0xFFFFAC41);
  static const Color pink = Color(0xFFFF1E56);
  static const Color white = Color(0xFFd9d9d9);
  static const Color darker = Color(0xFF1E1E1E);
}
